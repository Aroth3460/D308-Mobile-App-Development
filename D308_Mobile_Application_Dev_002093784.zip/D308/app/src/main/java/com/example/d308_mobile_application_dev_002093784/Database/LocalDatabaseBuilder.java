package com.example.d308_mobile_application_dev_002093784.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.example.d308_mobile_application_dev_002093784.Entities.Excursion;
import com.example.d308_mobile_application_dev_002093784.Entities.Vacation;
import com.example.d308_mobile_application_dev_002093784.Util.Converters;
import com.example.d308_mobile_application_dev_002093784.dao.ExcursionDao;
import com.example.d308_mobile_application_dev_002093784.dao.VacationDao;

@Database(entities = {Vacation.class, Excursion.class}, version = 2, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class LocalDatabaseBuilder extends RoomDatabase {
    public abstract VacationDao vacationDao();
    public abstract ExcursionDao excursionDao();

    private static volatile LocalDatabaseBuilder ldb_instance;

    public static LocalDatabaseBuilder getDatabase(final Context context) {
        if (ldb_instance==null) {
            synchronized (LocalDatabaseBuilder.class) {
                if(ldb_instance==null) {
                    ldb_instance= Room.databaseBuilder(context.getApplicationContext(), LocalDatabaseBuilder.class, "LocalRoomDatabase.db")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
    return ldb_instance;
    }

    public void clearData(){
        new Thread(() -> {
           ldb_instance.clearAllTables();
        });
    }
}
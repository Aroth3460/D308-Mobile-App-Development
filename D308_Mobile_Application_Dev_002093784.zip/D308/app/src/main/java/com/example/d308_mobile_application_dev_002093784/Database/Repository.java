package com.example.d308_mobile_application_dev_002093784.Database;

import android.app.Application;

import com.example.d308_mobile_application_dev_002093784.Entities.Excursion;
import com.example.d308_mobile_application_dev_002093784.Entities.Vacation;
import com.example.d308_mobile_application_dev_002093784.dao.ExcursionDao;
import com.example.d308_mobile_application_dev_002093784.dao.VacationDao;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Repository {
    private VacationDao vacationDao;
    private ExcursionDao excursionDao;

    private List<Vacation> allVacations;
    private List<Excursion> allExcursions;

    private static int num_threads=4;
    static final ExecutorService dbExecutor = Executors.newFixedThreadPool(num_threads);

    public Repository(Application application) {
        LocalDatabaseBuilder ldb = LocalDatabaseBuilder.getDatabase(application);
        vacationDao=ldb.vacationDao();
        excursionDao=ldb.excursionDao();
        //ldb.clearAllTables();
    }

    public List<Vacation> getAllVacations(){
        dbExecutor.execute(()->{
            allVacations=vacationDao.getAllVacations();
        });

        try {
            Thread.sleep(1000);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }

        return allVacations;
    }



    public List<Excursion> getAllExcursions(){

        dbExecutor.execute(() -> {
            allExcursions=excursionDao.getAllExcursions();
        });

        try {
            Thread.sleep(1000);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }

        return allExcursions;
    }

    public Vacation getVacationByID(int id){
        List<Vacation> allVacations = getAllVacations();
        for (Vacation v : allVacations) {
            if (v.getVacationID() == id) {
                return v;
            }
        }
        return null;
    }

    public void insert(Vacation vacation) {
        dbExecutor.execute(() ->{
            vacationDao.insert(vacation);
        });

        try{
            Thread.sleep(1000);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }
    }

    public void update(Vacation vacation) {
        dbExecutor.execute(() -> {
            vacationDao.update(vacation);
        });

        try{
            Thread.sleep(1000);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }
    }

    public void delete(Vacation vacation) {
        dbExecutor.execute(() -> {
            vacationDao.delete(vacation);
        });

        try{
            Thread.sleep(1000);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }
    }

    public void insert(Excursion excursion) {
        dbExecutor.execute(() ->{
            excursionDao.insert(excursion);
        });

        try{
            Thread.sleep(1000);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }
    }

    public void update(Excursion excursion) {
        dbExecutor.execute(() ->{
            excursionDao.update(excursion);
        });

        try{
            Thread.sleep(1000);
        } catch (InterruptedException ie) {
            ie.printStackTrace();
        }
    }

    public void delete(Excursion excursion) {
        dbExecutor.execute(() -> {
            excursionDao.delete(excursion);
        });

        try{
            Thread.sleep(1000);
        } catch (InterruptedException ie) {
            ////
            ie.printStackTrace();
        }
    }
}

package com.example.d308_mobile_application_dev_002093784.UI;

import static com.example.d308_mobile_application_dev_002093784.Util.StringDateFormatUtil.sdf;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.d308_mobile_application_dev_002093784.Database.Repository;
import com.example.d308_mobile_application_dev_002093784.Entities.Excursion;
import com.example.d308_mobile_application_dev_002093784.Entities.Vacation;
import com.example.d308_mobile_application_dev_002093784.R;
import com.example.d308_mobile_application_dev_002093784.Util.AlarmUtil;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ExcursionDetails extends AppCompatActivity {

    String excursionTitle;

    Excursion currentExcursion;

    Date excursionDate;

    Date vacationStartDate;

    Date vacationEndDate;

    String vacationTitle;

    String vacationHotel;

    int vacationID;

    int excursionID;

    Repository repository;

    EditText editExcursionTitle;

    Button excursionDateBtn;

    DatePickerDialog.OnDateSetListener dpdDate;

    final Calendar excursionCalendar=Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_excursion_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        repository = new Repository(getApplication());
        vacationID = getIntent().getIntExtra("vacationID", -1);
//        vacationTitle = getIntent().getStringExtra("vacationTitle");
//        vacationHotel = getIntent().getStringExtra("vacationHotel");
        excursionDate = (Date)getIntent().getSerializableExtra("excursion_date");
        excursionID = getIntent().getIntExtra("excursionID", -1);
        excursionTitle = getIntent().getStringExtra("title");
        //vacationStartDate = (Date)getIntent().getSerializableExtra("start_date");
        //vacationEndDate = (Date)getIntent().getSerializableExtra("end_date");

        if (vacationID != -1 && excursionDate != null && excursionID != -1 && excursionTitle != null) {
            currentExcursion = new Excursion(
                    excursionID,
                    excursionTitle,
                    excursionDate,
                    vacationID
                    );
        }

        editExcursionTitle = findViewById(R.id.editExcursionTitle);
        editExcursionTitle.addTextChangedListener(txtWatcherTitle);
        if (excursionTitle != null)
        {
            editExcursionTitle.setText(excursionTitle);
        }




        //String dateFormat = "MM/dd/yy";
        //SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);

        excursionDateBtn = findViewById(R.id.excursionDateBtn);
        if (excursionDate != null) {
            //==startCalendar.setTime(start_dateExtra);
            excursionDateBtn.setText(sdf.format(excursionDate));//start_date.toString());
        }
        Vacation vacation = null;
        if (vacationID != -1) {
            //List<Vacation> allVacations = repository.getAllVacations();
           vacation = repository.getVacationByID(vacationID);
        }
        if (vacation != null) {
            vacationStartDate = vacation.getStart_date();
            vacationEndDate = vacation.getEnd_date();
        }


        excursionDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date date;
                String dateInfo = excursionDateBtn.getText().toString();
                try{
                    excursionCalendar.setTime(sdf.parse(dateInfo));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                new DatePickerDialog(ExcursionDetails.this,
                        dpdDate,
                        excursionCalendar.get(Calendar.YEAR),
                        excursionCalendar.get(Calendar.MONTH),
                        excursionCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        dpdDate=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                excursionCalendar.set(Calendar.YEAR, year);
                excursionCalendar.set(Calendar.MONTH, month);
                excursionCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                String currentTimeString = sdf.format(excursionCalendar.getTime());
                if (vacationStartDate != null && vacationEndDate != null) {
                    String vacationStartDateString = sdf.format(vacationStartDate);
                    String vacationEndDateString = sdf.format(vacationEndDate);

                    if (excursionCalendar.getTime().before(vacationStartDate) || excursionCalendar.getTime().after(vacationEndDate)){
                        if (currentTimeString.equals(vacationStartDateString) || currentTimeString.equals(vacationEndDateString)) {
                            excursionDate = excursionCalendar.getTime();
                            excursionDateBtn.setText(sdf.format(excursionDate));
                            //showDateAlertDialog(editExcursionTitle.getText().toString(), excursionCalendar.getTime());
                        }
                        else {
                            Toast.makeText(ExcursionDetails.this, "Date must be during the vacation timeframe.", Toast.LENGTH_LONG).show();
                            excursionDate = null;
                        }
                    }
                    else {
                        excursionDate = excursionCalendar.getTime();
                        excursionDateBtn.setText(sdf.format(excursionDate));

                        //showDateAlertDialog(editExcursionTitle.getText().toString(), excursionCalendar.getTime());
                    }
                } else {
                    Toast.makeText(ExcursionDetails.this, "There is no start/end date for the associated vacation. This excursion may not be saved properly.", Toast.LENGTH_LONG).show();
                    //excursionDate = excursionCalendar.getTime();
                }
            }
        };
    };

//    @SuppressLint("MissingSuperCall")
//    @Override
//    public void onBackPressed() {
//        //super.onBackPressed();
//        Intent intent = new Intent();
//        intent.putExtra("start_date", vacationStartDate);
//        intent.putExtra("end_date", vacationEndDate);
//        intent.putExtra("vacationID", vacationID);
////        intent.putExtra("vacationTitle", vacationTitle);
////        intent.putExtra("vacationHotel", vacationHotel);
//        setResult(RESULT_OK, intent);
//    }

//    private void showDateAlertDialog(String title, Date date) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(ExcursionDetails.this);
//        boolean showAlertBool = FALSE;
//        Date currentDate = new Date();
//        String dateCheckString = sdf.format(date);
//        String currentDateString = sdf.format(currentDate);
//
//        if (date != null && dateCheckString.equals(currentDateString)) {
//            showAlertBool = TRUE;
//            if (title != null && !title.isEmpty() && title != "") {
//                builder.setTitle("Excursion: " + title);
//                builder.setMessage("Excursion Day!");
//            } else {
//                builder.setTitle("Excursion: N/A");
//            }
//        }
//
//        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//
//            }
//        });
//
//        if (showAlertBool) {
//            AlertDialog alertDialog = builder.create();
//            alertDialog.show();
//        }
//    }


    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_excursion_details, menu);
        //this.finish();
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // TEST FOR COMMIT STEPS B-3-g & B-3-h
        if (item.getItemId()==R.id.excursionSave) {
            Excursion excursion;
            if (excursionID == -1) {
                if (repository.getAllExcursions().size() == 0) {
                    excursionID = 1;
                } else {
                    excursionID = repository.getAllExcursions().get(repository.getAllExcursions().size() - 1).getExcursionID() + 1;
                }
                try {
                    if (excursionDate != null) {
                        excursion = new Excursion(
                                excursionID,
                                excursionTitle,
                                excursionDate,
                                vacationID
                        );
                        repository.insert(excursion);
                        currentExcursion = excursion;
                        Toast.makeText(ExcursionDetails.this, "The excursion was saved successfully.", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(ExcursionDetails.this, "The excursion could not be saved. Set the date before saving.", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else {
                try {
                    if (excursionDate != null) {
                        excursion = new Excursion(
                                excursionID,
                                editExcursionTitle.getText().toString(),
                                excursionDate,
                                vacationID
                        );
                        currentExcursion = excursion;
                        repository.update(excursion);
                        Toast.makeText(ExcursionDetails.this, "The excursion was updated successfully.", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(ExcursionDetails.this, "The excursion could not be saved or updated.", Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
                return true;
        }
        if (item.getItemId()==R.id.excursionDelete) {
            for (Excursion ex : repository.getAllExcursions()) {
                if (ex.getVacationID() == excursionID) {
                    currentExcursion = ex;
                }
            }

            if (currentExcursion != null) {
                repository.delete(currentExcursion);
                Toast.makeText(ExcursionDetails.this, "The excursion was deleted", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(ExcursionDetails.this, "The excursion could not be deleted. Make sure the excursion is saved before deletion.", Toast.LENGTH_LONG).show();
            }
        }
        if (item.getItemId()==R.id.setAlarmExcursion) {
            for (Excursion ex : repository.getAllExcursions()) {
                if (ex.getVacationID()==excursionID) {
                    currentExcursion = ex;
                }
            }

            if (currentExcursion != null) {
                AlarmUtil.setExcursionAlarm(ExcursionDetails.this, excursionCalendar, editExcursionTitle.getText().toString());
            }
            else {
                Toast.makeText(ExcursionDetails.this, "Save excursion before setting an alarm.", Toast.LENGTH_LONG).show();
            }
        }
            return super.onOptionsItemSelected(item);
    }

    // TEST Commit
    TextWatcher txtWatcherTitle = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            excursionTitle = s.toString();
        }
    };
}
package com.example.d308_mobile_application_dev_002093784.UI;

import static com.example.d308_mobile_application_dev_002093784.Util.StringDateFormatUtil.dateFormat;
import static com.example.d308_mobile_application_dev_002093784.Util.StringDateFormatUtil.sdf;
import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.d308_mobile_application_dev_002093784.Database.Repository;
import com.example.d308_mobile_application_dev_002093784.Entities.Excursion;
import com.example.d308_mobile_application_dev_002093784.Entities.Vacation;
import com.example.d308_mobile_application_dev_002093784.R;
import com.example.d308_mobile_application_dev_002093784.Util.AlarmUtil;
import com.example.d308_mobile_application_dev_002093784.Util.LocalReceiver;
import com.example.d308_mobile_application_dev_002093784.Util.StringDateFormatUtil;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class VacationDetails extends AppCompatActivity {

    int vacationIDExtra;

    int numExcursions;

    String titleExtra;

    String hotelExtra;

    String titleLocal;

    String hotelLocal;

    Date start_dateExtra;

    Date end_dateExtra;

    Date start_date;

    Date end_date;

    EditText editTitle;

    EditText editHotel;

    Repository repository;

    Vacation currentVacation;

    Button startDateButton;
    Button endDateButton;

    FloatingActionButton fab;

    DatePickerDialog.OnDateSetListener dpdDate;

    DatePickerDialog.OnDateSetListener dpdDate2;

    final Calendar startCalendar=Calendar.getInstance();
    final Calendar endCalendar=Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vacation_details);

        // RecyclerView Intent Data
        titleExtra = getIntent().getStringExtra("title");
        hotelExtra = getIntent().getStringExtra("hotel");
        vacationIDExtra = getIntent().getIntExtra("vacationID", -1);
        start_dateExtra = (Date)getIntent().getSerializableExtra("start_date");
        end_dateExtra = (Date)getIntent().getSerializableExtra("end_date");
        editTitle = findViewById(R.id.editTitleText);
        editHotel = findViewById(R.id.editHotelText);

        if (titleExtra != null) {
            editTitle.setText(titleExtra);
        }
        if (hotelExtra != null) {
            editHotel.setText(hotelExtra);
        }

        RecyclerView recyclerView = findViewById(R.id.excursionsRecView);
        repository = new Repository(getApplication());
        final ExcursionAdapter excursionAdapter = new ExcursionAdapter(this);
        recyclerView.setAdapter(excursionAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        List<Excursion> filteredExcursions = new ArrayList<>();
        for (Excursion ex : repository.getAllExcursions()){
            if (ex.getVacationID() == vacationIDExtra) {
                filteredExcursions.add(ex);
            }
        }
        excursionAdapter.setExcursions(filteredExcursions);

        editTitle.addTextChangedListener(txtWatcherTitle);
        editHotel.addTextChangedListener(txtWatcherHotel);
        fab = findViewById(R.id.fabEnterData);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VacationDetails.this, ExcursionDetails.class);
                if (vacationIDExtra != -1) {
                    intent.putExtra("vacationID", vacationIDExtra);
//                    intent.putExtra("vacationTitle", editTitle.getText());
//                    intent.putExtra("vacationHotel", editHotel.getText());
                    intent.putExtra("start_date", start_date);
                    intent.putExtra("end_date", end_date);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(VacationDetails.this, "You must save your vacation before adding an excursion", Toast.LENGTH_LONG).show();
                }
            }
        });

        // Start Date Button Config
        startDateButton = findViewById(R.id.start_date_btn);
        //String dateFormat = "MM/dd/yy";
        //SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);

        //String dateFormat = StringDateFormatUtil.dateFormat;

        if (start_dateExtra != null) {
            //==startCalendar.setTime(start_dateExtra);
            start_date = start_dateExtra;
            startCalendar.setTime(start_date);
            startDateButton.setText(sdf.format(start_date));//start_date.toString());
        }
        // Commit for new token.
        startDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date date;
                String dateInfo = startDateButton.getText().toString();
                try{
                    startCalendar.setTime(sdf.parse(dateInfo));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                new DatePickerDialog(VacationDetails.this,
                        dpdDate,
                        startCalendar.get(Calendar.YEAR),
                        startCalendar.get(Calendar.MONTH),
                        startCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        dpdDate=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                try {
                    Calendar localCalendar = Calendar.getInstance();
                    localCalendar.set(Calendar.YEAR, year);
                    localCalendar.set(Calendar.MONTH, month);
                    localCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                    Date dateLocal = localCalendar.getTime();
                    //dateLocal = StringDateFormatUtil.timeZoneDateConverter(dateLocal, "CST", "CDT");
                    boolean isUpdateButtonLabel = FALSE;
                    isUpdateButtonLabel = updateButtonDateLabel(TRUE, dateLocal);

                    if (isUpdateButtonLabel) {
                        //showDateAlertDialog(editTitle.getText().toString(), startCalendar.getTime(), TRUE);
                        startCalendar.set(Calendar.YEAR, year);
                        startCalendar.set(Calendar.MONTH, month);
                        startCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        // TEST COMMIT
        // End Date Button Config
        endDateButton = findViewById(R.id.end_date_btn);
        if (end_dateExtra != null) {
            //endCalendar.setTime(start_dateExtra);
            end_date = end_dateExtra;

            endCalendar.setTime(end_date);
            endDateButton.setText(sdf.format(end_date));
        }
        endDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date date;
                String dateInfo = endDateButton.getText().toString();
                try {
                    endCalendar.setTime(sdf.parse(dateInfo));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                new DatePickerDialog(VacationDetails.this,
                        dpdDate2,
                        endCalendar.get(Calendar.YEAR),
                        endCalendar.get(Calendar.MONTH),
                        endCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        dpdDate2=new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                Calendar localCalendar = Calendar.getInstance();
                localCalendar.set(Calendar.YEAR, year);
                localCalendar.set(Calendar.MONTH, month);
                localCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                Date dateLocal = localCalendar.getTime();

                boolean isUpdateButtonLabel = FALSE;
                isUpdateButtonLabel = updateButtonDateLabel(FALSE, dateLocal);

                if (isUpdateButtonLabel) {
                    //showDateAlertDialog(editTitle.getText().toString(), end_date, FALSE);
                    endCalendar.set(Calendar.YEAR, year);
                    endCalendar.set(Calendar.MONTH, month);
                    endCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                }
            }
        };
    }

//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent intentData) {
//
//        super.onActivityResult(requestCode, resultCode, intentData);
//        if (requestCode == 1) {
//            if (resultCode == RESULT_OK) {
//                String titleExtraBck = intentData.getStringExtra("vacationTitle");
//                String hotelExtraBck = intentData.getStringExtra("vacationHotel");
//                Date startDateExtraBck = (Date)intentData.getSerializableExtra("start_date");
//                Date endDateExtraBck = (Date)intentData.getSerializableExtra("end_date");
//                startCalendar.setTime(startDateExtraBck);
//                endCalendar.setTime(endDateExtraBck);
//                editTitle.setText(titleExtraBck);
//                editHotel.setText(hotelExtraBck);
//            }
//        }
//    }

//    private void showDateAlertDialog(String title, Date date, boolean startOrEnd) {
//        AlertDialog.Builder builder = new AlertDialog.Builder(VacationDetails.this);
//        boolean showAlertBool = FALSE;
//        Date currentDate = new Date();
//        String dateCheckString = sdf.format(date);
//        String currentDateString = sdf.format(currentDate);
//
//        if (date != null && dateCheckString.equals(currentDateString)) {
//            showAlertBool = TRUE;
//            if (title != null && !title.isEmpty() && title != "") {
//                builder.setTitle("Vacation: " + title);
//                if (startOrEnd) {
//                    builder.setMessage("Starting on: " + sdf.format(date));
//                } else {
//                    builder.setMessage("Ending on: " + sdf.format(date));
//                }
//            } else {
//                builder.setTitle("Vacation: N/A");
//                if (startOrEnd) {
//                    builder.setMessage("Starting on: " + sdf.format(date));
//                } else {
//                    builder.setMessage("Ending on " + sdf.format(date));
//                }
//            }
//        }
//
//        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//
//            }
//        });
//
//        if (showAlertBool) {
//            AlertDialog alertDialog = builder.create();
//            alertDialog.show();
//        }
//    }


    // Updates the button date label as well as alerting the user if the start/end date.
    private boolean updateButtonDateLabel(boolean dateType, Date dateToSet) {
        //String format = "MM/dd/yy";
        //SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.US);
        boolean isUpdated = FALSE;
        if (dateType == TRUE) {
//            if (end_date == null){
//                Toast.makeText(VacationDetails.this, "First, choose an End Date, then a Start Date.", Toast.LENGTH_LONG).show();
//            }
            if (end_date != null) {
                if (dateWithinRange(dateToSet, end_date)) {
                    start_date = dateToSet;
                    //startDateButton.setText(sdf.format(startCalendar.getTime()));
                    startDateButton.setText(sdf.format(start_date));
                    isUpdated = TRUE;
                    Toast.makeText(VacationDetails.this, "Start Date Changed To: " + start_date, Toast.LENGTH_LONG).show();
//                } else if (end_date == null) {
////                    start_date = dateToSet;
////                    startDateButton.setText(sdf.format(start_date));
////                    isUpdated = TRUE;
////                    Toast.makeText(VacationDetails.this, "Start Date Changed To: " + start_date, Toast.LENGTH_LONG).show();
//                } else //if (start_date != null && end_date != null)
                } else {
                    Toast.makeText(VacationDetails.this, "Start Date must be before the end date.", Toast.LENGTH_LONG).show();
                    isUpdated = FALSE;
                }
            } else {
                start_date = dateToSet;
                startDateButton.setText(sdf.format(start_date));
                isUpdated = TRUE;
                Toast.makeText(VacationDetails.this, "Start Date Changed To: " + start_date, Toast.LENGTH_LONG).show();
            }
        } else {
            if (start_date != null) {
                if (dateWithinRange(start_date, dateToSet)) {
                    endDateButton.setText(sdf.format(dateToSet));
                    end_date = dateToSet;
                    isUpdated = TRUE;
                    Toast.makeText(VacationDetails.this, "End Date Changed To: " + end_date, Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(VacationDetails.this, "End Date must be after the start date.", Toast.LENGTH_LONG).show();
                    isUpdated = FALSE;
                }
            } else {
                end_date = dateToSet;
                endDateButton.setText(sdf.format(end_date));
                isUpdated = TRUE;
                Toast.makeText(VacationDetails.this, "End Date Changed To: " + end_date, Toast.LENGTH_LONG).show();
            }
//            else if (start_date == null) {
//                endDateButton.setText(sdf.format(dateToSet));
//                end_date = dateToSet;
//                isUpdated = TRUE;
//                Toast.makeText(VacationDetails.this, "End Date Changed To: " + end_date, Toast.LENGTH_LONG).show();
//            }
        }
        return isUpdated;
    }

    TextWatcher txtWatcherTitle = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            titleLocal = s.toString();
        }
    };

    TextWatcher txtWatcherHotel = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            hotelLocal = s.toString();
        }
    };

    // Checks if start/end dates are correct.
    private static boolean dateWithinRange(Date startDate, Date endDate) {
        boolean dateBool = TRUE;
        if (startDate.after(endDate) || endDate.before(startDate)) {
            dateBool = FALSE;
        }
        else {
            dateBool = TRUE;
        }

        return dateBool;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_vacation_details, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()== android.R.id.home) {
            this.finish();
            return true;
        }

        // ADD SAMPLE EXCURSIONS LOGIC
//        if (item.getItemId()==R.id.addSampleExcursions) {
//            if (vacationIDExtra == -1) {
//                Toast.makeText(VacationDetails.this, "Please save vacation before adding excursions.", Toast.LENGTH_LONG).show();
//            }
//            else {
//                int excursionIDLocal;
//
//                if (repository.getAllExcursions().size() == 0) {
//                    excursionIDLocal = 1;
//                }
//                else {
//                    excursionIDLocal = repository.getAllExcursions().get(repository.getAllExcursions().size() - 1).getExcursionID() + 1;
//                }
//
//                Date sampleExcursionDate = new Date(2024, 6, 29, 4, 15, 0);
//                Excursion excursion = new Excursion(excursionIDLocal, "Hot Springs", sampleExcursionDate, vacationIDExtra);
//                repository.insert(excursion);
//                excursion = new Excursion(++excursionIDLocal, "Pool & Rec Room", sampleExcursionDate, vacationIDExtra);
//                repository.insert(excursion);
//
//                RecyclerView recyclerView = findViewById(R.id.excursionsRecView);
//                final ExcursionAdapter excursionAdapter = new ExcursionAdapter(this);
//                recyclerView.setAdapter(excursionAdapter);
//                recyclerView.setLayoutManager(new LinearLayoutManager(this));
//                List<Excursion> filteredExcursions = new ArrayList<>();
//                for (Excursion ex : repository.getAllExcursions()) {
//                    if (ex.getVacationID()==vacationIDExtra) {
//                        filteredExcursions.add(ex);
//                    }
//                }
//                excursionAdapter.setExcursions(filteredExcursions);
//                return true;
//            }
//        }
        // SAVE VACATION LOGIC
        if (item.getItemId()==R.id.saveVacation) {
            Vacation vacation;
            if (vacationIDExtra == -1) {
                if (repository.getAllVacations().size() == 0) {
                    vacationIDExtra = 1;
                }
                else {
                    vacationIDExtra = repository.getAllVacations().get(repository.getAllVacations().size() - 1).getVacationID() + 1;
                }

                vacation = new Vacation(
                        vacationIDExtra,
                        editTitle.getText().toString(),
                        editHotel.getText().toString(),
                        start_date,
                        end_date
                );

                if (start_date != null && end_date != null) {
                    repository.insert(vacation);
                    currentVacation = vacation;
                    Toast.makeText(VacationDetails.this, "Vacation: " + vacation.getTitle() + " saved successfully.", Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(VacationDetails.this, "Both dates must be set before being saved.", Toast.LENGTH_LONG).show();
                    vacationIDExtra = -1;
                }
            }
            else {
                try {
                    vacation = new Vacation(
                            vacationIDExtra,
                            editTitle.getText().toString(),
                            editHotel.getText().toString(),
                            start_date,
                            end_date);

                    if (start_date != null && end_date != null) {
                        repository.update(vacation);
                        currentVacation = vacation;
                        Toast.makeText(VacationDetails.this, "Vacation: " + vacation.getTitle() + " updated successfully.", Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(VacationDetails.this, "Both dates must be set before being saved.", Toast.LENGTH_LONG).show();
                        vacationIDExtra =-1;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return true;
        }

        // DELETE VACATION LOGIC
        if (item.getItemId() == R.id.deleteVacation) {
            for (Vacation v : repository.getAllVacations()) {
                if (v.getVacationID()==vacationIDExtra) {
                    currentVacation = v;
                }
            }
            numExcursions = 0;
            for (Excursion ex : repository.getAllExcursions()) {
                if (ex.getVacationID() == vacationIDExtra) {
                    ++numExcursions;
                }
            }

            // Toast user on deletion status.
            // Prevent vacation deletions w/ excursions.
            if (numExcursions == 0 && currentVacation != null) {
                try {
                    repository.delete(currentVacation);
                    Toast.makeText(VacationDetails.this, currentVacation.getTitle() + " was deleted", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else {
                try {
                    Toast.makeText(VacationDetails.this, currentVacation.getTitle() + " cannot be deleted. The associated excursion(s) must first be deleted (if any). Make sure the vacation is saved before deletion.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(VacationDetails.this, "This vacation cannot be deleted. Make sure the vacation is saved before deletion.", Toast.LENGTH_LONG).show();
                }
            }
            return true;
        }

        if (item.getItemId()==R.id.setAlarm) {

            String[] choices = {"Start Date", "End Date", "Both"};
            final int[] itemChoiceIndex = {0};
            final String[] selectedDateFinal = {""};

            for (Vacation v : repository.getAllVacations()) {
                if (v.getVacationID()==vacationIDExtra) {
                    currentVacation = v;
                }
            }

            if (currentVacation != null) {
                AlertDialog.Builder builder = new AlertDialog.Builder(VacationDetails.this);
                builder.setTitle("Set Alarm");
                builder.setSingleChoiceItems(choices, 0, ((dialog, which) -> {
                    itemChoiceIndex[0] = which;
                }));

                builder.setPositiveButton("OK", ((dialog, which) -> {
                    String selectedDate = choices[itemChoiceIndex[0]];

                    switch (selectedDate) {
                        case "Start Date":
                            //AlarmUtil.setAlarm(VacationDetails.this, startCalendar);
                            //dialog.dismiss();
                            selectedDateFinal[0] = selectedDate;
                            AlarmUtil.setAlarm(VacationDetails.this, startCalendar, TRUE, editTitle.getText().toString());
                            break;
                        case "End Date":
                            //AlarmUtil.setAlarm(VacationDetails.this, endCalendar);
                            selectedDateFinal[0] = selectedDate;
                            AlarmUtil.setAlarm(VacationDetails.this, endCalendar, FALSE, editTitle.getText().toString());
                            break;
                            //break;
                        case "Both":
                            selectedDateFinal[0] = selectedDate;
                            AlarmUtil.setAlarm(VacationDetails.this, startCalendar, TRUE, editTitle.getText().toString());
                            AlarmUtil.setAlarm(VacationDetails.this, endCalendar, FALSE, editTitle.getText().toString());
                            break;
                    }

                    dialog.dismiss();
                }));

                builder.setNegativeButton("Cancel", ((dialog, which) -> {
                    dialog.dismiss();
                }));

                AlertDialog dialog = builder.create();
                dialog.show();

//                Long trigger = 0L;
//                //trigger =
//                Intent intent = new Intent(VacationDetails.this, LocalReceiver.class);
//                intent.putExtra("start_date_msg", "Vacation: " + currentVacation.getTitle() + " is starting on" + startDateString);
//                PendingIntent sender = PendingIntent.getBroadcast(VacationDetails.this, ++MainActivity.numAlert, intent, PendingIntent.FLAG_IMMUTABLE);
//                AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
//                alarmManager.set(AlarmManager.RTC_WAKEUP, trigger, sender);
            }
            else {
                Toast.makeText(VacationDetails.this, "The vacation must be saved before setting an alarm.", Toast.LENGTH_LONG).show();
            }

            return super.onOptionsItemSelected(item);
        }

        if (item.getItemId() == R.id.copyVacationData) {
            ClipboardManager clipboard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            String vacationDetailsString = "";
            List<Excursion> associatedExcursions = new ArrayList<>();

            for (Vacation v : repository.getAllVacations()) {
                if (v.getVacationID()==vacationIDExtra) {
                    currentVacation = v;
                }
            }

            for (Excursion ex : repository.getAllExcursions()) {
                if (ex.getVacationID()==currentVacation.getVacationID()){
                    associatedExcursions.add(ex);
                }
            }

            if (currentVacation == null) {
                Toast.makeText(VacationDetails.this, "Vacation must be saved before being copied.", Toast.LENGTH_LONG).show();
            }
            else {
                String titleString = currentVacation.getTitle();
                String hotelString = currentVacation.getHotel();
                int idINT = currentVacation.getVacationID();
                String idString = Integer.toString(idINT);
                String startDateString = sdf.format(currentVacation.getStart_date());
                String endDateString = sdf.format(currentVacation.getEnd_date());

                vacationDetailsString = "VacationID: " + idString;
                vacationDetailsString += System.lineSeparator();
                vacationDetailsString += "Title: " + titleString;
                vacationDetailsString += System.lineSeparator();
                vacationDetailsString += "Hotel: " + hotelString;
                vacationDetailsString += System.lineSeparator();
                vacationDetailsString += "Start Date: " + startDateString;
                vacationDetailsString += System.lineSeparator();
                vacationDetailsString += "End Date: " + endDateString;

                if (associatedExcursions.size()!=0) {
                    for (Excursion ex : associatedExcursions) {
                        if(ex.getExcursionID()!=-1) {
                            String idExcursionString = Integer.toString(ex.getExcursionID());
                            vacationDetailsString += System.lineSeparator();
                            vacationDetailsString += "-------------------------------";
                            vacationDetailsString += System.lineSeparator();
                            vacationDetailsString += "ExcursionID:" + idExcursionString;
                            vacationDetailsString += System.lineSeparator();
                            vacationDetailsString += "Title: " + ex.getTitle();
                            vacationDetailsString += System.lineSeparator();
                            vacationDetailsString += "Date: " + sdf.format(ex.getExcursion_date());
                        }
                    }
                }

                ClipData clip = ClipData.newPlainText("simple text", vacationDetailsString);

                clipboard.setPrimaryClip(clip);
            }
        }

        return super.onOptionsItemSelected(item);
    }

}
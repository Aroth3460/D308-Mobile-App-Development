package com.example.d308_mobile_application_dev_002093784.UI;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.d308_mobile_application_dev_002093784.Database.Repository;
import com.example.d308_mobile_application_dev_002093784.Entities.Vacation;
import com.example.d308_mobile_application_dev_002093784.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Date;
import java.util.List;

public class VacationList extends AppCompatActivity {

    private Repository repository;

    private Vacation sampleVacation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_vacation_list);
        repository = new Repository(getApplication());
        //this.repository = new Repository(getApplication());
        FloatingActionButton fab = findViewById(R.id.vacationListFAB);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VacationList.this, VacationDetails.class);
                startActivity(intent);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        List<Vacation> allVacations = repository.getAllVacations();
        RecyclerView recyclerView = findViewById(R.id.vacationListRecView);
        final VacationAdapter vacationAdapter = new VacationAdapter(this);
        recyclerView.setAdapter(vacationAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        vacationAdapter.setVacations(allVacations);
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//       // getMenuInflater().inflate(R.menu.);
//        //getMenuInflater().inflate(R.menu.);
//        getMenuInflater().inflate(R.menu.menu_vacation_list, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        if (item.getItemId() == android.R.id.home) {
//            this.finish();
//            //Intent intent=new Intent()
//            return true;
//        }
//
//        if (item.getItemId() == R.id.addSampleVacations) {
//
//            //Repository repoVar = new Repository(getApplication());
//            Date sampleStartDate1 = new Date(2020, 3, 21, 4, 15, 0);
//            Date sampleStartDate2 = new Date(2024, 5, 29, 4, 15, 0);
//            Date sampleEndDate1 = new Date(2020, 4, 17, 8, 10, 0);
//            Date sampleEndDate2 = new Date(2024, 6, 10, 6, 15, 0);
//
//            Vacation sampleVacationLocal1 = new Vacation(0,"Jackson State Park", "Jackson Inn", sampleStartDate1, sampleEndDate1);
//            repository.insert(sampleVacationLocal1);
//            Vacation sampleVacationLocal2 = new Vacation(0,"Bahamas Trip", "Bahamas Grand Hotel", sampleStartDate2, sampleEndDate2);
//            //repoVar.insert(sampleVacationLocal2);
//            repository.insert(sampleVacationLocal2);
//            //Vacation vacation1 = new Vacation(1, "Bahamas Getaway", "Bahamas Inn", sampleStartDate, sampleEndDate);
////            if (sampleVacation == null){
////                sampleVacation = new Vacation(
////                        "Bahamas Getaway",
////                        "Bahamas Inn",
////                        sampleStartDate,
////                        sampleEndDate);
////            }
//            //repoVar.insert(new Vacation("Jackson State Park", "Jackson Inn", sampleStartDate, sampleEndDate));
//            //repository.insert(sampleVacation);
//            //repository.insert(new Vacation("Title_TEST_Vacay", "Hotel_TEST_Vacay", sampleStartDate, sampleEndDate));
//
//            List<Vacation> allVacations = repository.getAllVacations();
//            RecyclerView recyclerView = findViewById(R.id.vacationListRecView);
//            final VacationAdapter vacationAdapter = new VacationAdapter(this);
//            recyclerView.setAdapter(vacationAdapter);
//            recyclerView.setLayoutManager(new LinearLayoutManager(this));
//            vacationAdapter.setVacations(allVacations);
//
//            return true;
//        }
//        return super.onOptionsItemSelected(item);
//    }

    @Override
    protected void onResume(){
          super.onResume();
        List<Vacation> allVacations = repository.getAllVacations();
        RecyclerView recyclerView = findViewById(R.id.vacationListRecView);
        final VacationAdapter vacationAdapter = new VacationAdapter(this);
        recyclerView.setAdapter(vacationAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        vacationAdapter.setVacations(allVacations);
    }
}
package com.example.d308_mobile_application_dev_002093784.Util;

import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.Locale;

public class StringDateFormatUtil {

    public static String dateFormat = "MM/dd/yy";
    public static SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);

//    public static Date timeZoneDateConverter(Date date, String originalTimeZone, String newTimeZone) {
//        ZoneId originalTimeZoneID = ZoneId.of(originalTimeZone);
//        ZoneId newTimeZoneID = ZoneId.of(newTimeZone);
//
//        ZonedDateTime originalZonedDateTime =
//                ZonedDateTime.ofInstant(date.toInstant(),
//                        ZoneId.systemDefault()).withZoneSameLocal(originalTimeZoneID);
//
//        ZonedDateTime newZoneDateTime = originalZonedDateTime
//                .withZoneSameInstant(newTimeZoneID)
//                .withZoneSameLocal(ZoneId.systemDefault());
//
//        return Date.from(newZoneDateTime.toInstant());
//    }
}

package com.example.d308_mobile_application_dev_002093784.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.d308_mobile_application_dev_002093784.Entities.Excursion;
import com.example.d308_mobile_application_dev_002093784.Entities.Vacation;

import java.util.List;

@Dao
public interface ExcursionDao {

    //@Query("SELECT * FROM Excursion")
    //public List<Vacation> getAllExcursions();

    @Query("SELECT * FROM Excursions ORDER BY excursionID ASC")
    public List<Excursion> getAllExcursions();

    @Query("SELECT * FROM Excursions WHERE vacationID=:id ORDER BY excursionID ASC")
    public List<Excursion> getExcursionsByVacation(int id);

    @Query("SELECT * FROM Excursions WHERE excursionID = :id")
    public Excursion findExcursionById(int id);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    public void insert(Excursion excursion);

    @Update
    public void update(Excursion excursion);

    @Delete
    public void delete(Excursion excursion);
}

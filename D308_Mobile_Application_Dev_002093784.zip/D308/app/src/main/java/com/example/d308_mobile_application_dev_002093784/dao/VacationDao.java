package com.example.d308_mobile_application_dev_002093784.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.d308_mobile_application_dev_002093784.Entities.Vacation;

import java.util.List;

@Dao
public interface VacationDao {

    @Query("SELECT * FROM Vacations ORDER BY vacationID ASC")
    public List<Vacation> getAllVacations();

    //@Query("SELECT * FROM Vacations")
    //public List<Vacation> loadAllByIds(int[] vacation_ids);

    @Query("SELECT * FROM Vacations WHERE vacationID = :id")
    public Vacation getVacationById(int id);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    public void insert(Vacation vacation);

    @Update
    public void update(Vacation vacation);

    @Delete
    public void delete(Vacation vacation);
}
